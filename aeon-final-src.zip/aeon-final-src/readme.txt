Hello, dear user.

You can play your media (video & audio) files in *Aeon* by doing one of these steps:

1). After you open the app, click on the "Open file" button, then choose the file using the "File Chooser Dialog". You can use your keyboard or mouse as below while you are at the dialog:
UP / DOWN = scroll the 'Listbox'.
LEFT / RIGHT = Change directories (folders).
ENTER = open the selected file.
You can also use the 'mouse wheel' to scroll, and then click "Open".
The media you play will be found under the "Playlist" in the menu.

2.) For the first time (and perhaps once in a while), you need to go to the "Settings", and then click the  "Scan my PC now" button, and add or delete folders where you want the app to 'search' your media files, and the click "Scan now" in the window that will popup. Goto the "My Songs" or "My Videos" and select a media to play. You can even "shuffle" the playlist or restore the original order.

Made with <:), by Peter Mwale. Find my contacts at the "About" page in the app! Lock yourself into the music / movies !

from os.path import join, abspath
import sys

def resource_path(relaive_path):
	try:
		base_path = sys._MEIPASS
	except:
		base_path  = abspath(".")

	return join(base_path, relaive_path)
import pyglet, os
from com.zero.aeon.child import *
from com.zero.aeon.const import *
from com.zero.aeon.app import App
from com.zero.aeon.movie import Movie
from com.zero.aeon.tags import getAlbumArt, getTrackInfo

        
class MediaList(Panel):
    
    def __init__(self, parent, name="Media"):
        super(MediaList, self).__init__(parent)
        
        label = Text(self, text=name, fg1=BLACK)
        label.pack(side=TOP, expand_x=YES)
        
        self.listBox = List(self, fun1=self.getRoot().openFile)
        self.listBox.pack(side=TOP, expand_x=YES, expand_y=YES)
        
        self.loadMedia()
        
        panel = Panel(self, bg1=SILVER, size_hint=(None, 18))
        panel.pack(side=BOTTOM, expand_x=YES)
        
        btn = Button(panel, text="Play")
        btn.pack(side=LEFT)
        
    def loadMedia(self):
        PATH = "/home/peter/Documents/music/PETER TOSH 2015/Peter Tosh/Mystic Man"
        
        for name in os.listdir(PATH):
            obj = os.path.join(PATH, name)
            if os.path.isfile(obj):
                self.listBox.insert(obj, "data/image/icon.png", True if self.name.startswith("audio") else False)

class VideoList(MediaList):
     
     def __init__(self, parent):
         super(VideoList, self).__init__(parent, "Videos")
         
class AudioList(MediaList):
     
     def __init__(self, parent):
         super(AudioList, self).__init__(parent, "Audios")
 
class Controls(Panel):
        
    def __init__(self, parent):
        super(Controls, self).__init__(parent, size_hint=(None, 36))
        
        #self.config({"ipadx": 100, "padx": 200, "ipady": 5})
        
        panel = Panel(self, bg1=SILVER, size_hint=(None, 18))
        panel.pack(side=TOP, expand_x=YES)
        
        self.ellapsed = Text(panel, text="00:00", fg1=BLACK)
        self.ellapsed.pack(side=LEFT)
        
        self.seeker = Slider(self)
        self.seeker.config({"padx": 83, "ipadx": 40})
        self.seeker.pack(side=LEFT, expand_x=YES)
        
        self.duration = Text(panel, text="00:00", fg1=BLACK)
        self.duration.pack(side=RIGHT)
        
        self.count = 0
        
    def draw(self):
        self.count += 1
        if self.count < 200 or self.isHovering():
            super().draw()
            pygame.mouse.set_visible(True)
        else:
            pygame.mouse.set_visible(False)
                
class MediaControl(Panel):
    
    def __init__(self, *args, **kwargs):
        super(MediaControl, self).__init__(*args, **kwargs)
        
        self.controls = Controls(self)
        
    def mouseMoved(self, pos):
        self.controls.count = 0
        
    def mouseDown(self, pos, btn, double_click):
        if double_click:
            self.getRoot().switchFullscreen()
        super().mouseDown(pos, btn, double_click)
    
    def keyDown(self, key, char):
        if key == K_f:
            self.getRoot().switchFullscreen()
        super().keyDown(key, char)

class AudioControl(MediaControl):
     
    def __init__(self, parent):
        super(AudioControl, self).__init__(parent)
        
        self.player = pyglet.media.Player() 
        #self.player.loop = True
               
        self.art = Image(self, "data/image/art.png")
        self.art.pack(expand_x=YES, expand_y=YES)
        self.config({"bg": self.art.getColor()})
        
        self.controls.pack(side=BOTTOM, expand_x=YES)
        
    def Play(self, file):
        if self.player.playing:
            self.player.pause()
        self.player = pyglet.media.Player()
        source = pyglet.media.load(file)
        self.trackLength = getTrackInfo(file)[-1]
        self.player.queue(source)
        self.player.play()
        
        self.getRoot().setTitle("{0} | Aeon Media Player".format(os.path.split(file)[1]))
        self.controls.seeker.config({"to": self.trackLength})
        
        album_art = getAlbumArt(file)
        
        if album_art is not None:
            self.art.config(({"image": pygame.image.load(album_art).convert_alpha()}))
            self.config({"bg": self.art.getColor()})
        
    def draw(self):
        super().draw()
        
        if not self.player.playing:
            return
        
        Min, Sec = divmod(self.player.time, 60)
        Hour, Min = divmod(Min, 60)
            
        Sec = str(int(Sec))
        Min = str(int(Min))
        Hour = str(int(Hour))
            
        if len(Sec) < 2:
                Sec = "0" + Sec
        if len(Min) < 2:
            Min = "0" + Min
        if len(Hour) < 2:
            Hour = "0" + Hour
                
        self.controls.ellapsed.setValue(Min + ":" + Sec)
        
        Min, Sec = divmod(self.trackLength-self.player.time, 60)
        Hour, Min = divmod(Min, 60)
            
        Sec = str(int(Sec))
        Min = str(int(Min))
        Hour = str(int(Hour))
            
        if len(Sec) < 2:
            Sec = "0" + Sec
        if len(Min) < 2:
            Min = "0" + Min
        if len(Hour) < 2:
            Hour = "0" + Hour
                
        self.controls.duration.setValue("-" + Min + ":" + Sec)
        
        self.controls.seeker.setValue(self.player.time)        
        #self.getRoot().timer.bind(tick, 1)
 
class VideoControl(MediaControl):
     
     def __init__(self, parent):
        super(VideoControl, self).__init__(parent)
         
        self.movie = Movie(self)
        self.movie.pack(expand_x=YES, expand_y=YES)
        
        self.controls.pack(side=BOTTOM, expand_x=YES)
         
     def Play(self, file):
        self.movie.play(file)
                
class Page(Image):
    
    def  __init__(self, parent, source, page_name, form=None):
        super(Page, self).__init__(parent, source=source)
        
        self.page_name = page_name     
        self.form = form   
        self.side = CENTER
        self.expand_x = self.expand_y = YES
        
    def mouseDown(self, pos, btn):
        if btn == LEFT_CLICK and self.isHovering() and self.form is not None:
            print(self.form.name)
            #self.getRoot().setCurrent(self.form)
        
    def mouseMoved(self, pos):
        if self.isHovering():
            self.resize((610, 610))
            self.parent.label.setValue("Tap to goto {0}".format(self.page_name))
        else:
            self.resize((350, 350))
            self.parent.label.setValue("")
        
class Pager(Panel):
    
    def __init__(self, parent):
        super(Pager, self).__init__(parent, bg1=SILVER)
              
        media = Page(self, "data/image/media.jpg", "Media", self.getRoot().mediaList)
        songs = Page(self, source="data/image/songs.png", page_name="Songs")
        artists = Page(self, source="data/image/artist.png", page_name="Artists")
        albums = Page(self, source="data/image/album.png", page_name="Albums")
        #playlists = Page(self, source="data/image/media.jpg", page_name="Playlists")
        videos = Page(self, source="data/image/movie.jpg", page_name="Videos")
        about = Page(self, source="data/image/info.png", page_name="About")
        
        self.pages = [media, songs, artists, albums, videos, about]
        self.index = 0
        
        for page in self.pages:
            page.resize((350, 350))
            
        self.label = Text(self, fg1=BLACK, bg1=SILVER, align=LEFT)
        self.label.pack(side=BOTTOM, expand_x=YES)
        
    def keyDown(self, key, char):
        if key == K_LEFT:
            x = self.index - 1
            self.index = x if x >= 0 else 0
        elif key == K_RIGHT:
            x = self.index + 1
            self.index = x if x <= len(self.pages)-1 else len(self.pages)-1
            
    def mouseDown(self, pos, btn):
        self.pages[self.index].mouseDown(pos, btn)
            
    def mouseMoved(self, pos):
        self.pages[self.index].mouseMoved(pos)
            
    def draw(self):
        self.initDraw()
        pygame.draw.rect(self.screen, self.bg, (*self.pos, *self.size))
        self.pages[self.index].draw()
        self.label.draw()
        
class Aeon(App):
    
    def onCreate(self, info):
        super(Aeon, self).onCreate(info, title="Aeon Media Player", size=(1000, 750))
        self.form = None    
        self.mediaList = MediaList(self)
        self.audioControl = AudioControl(self)
        self.videoControl = VideoControl(self)
        self.videoList = VideoList(self)
        self.audioList = AudioList(self)
        self.pager = Pager(self)
        self.setCurrent(self.videoList)
        
    def isAudio(self, file):
        return os.path.isfile(file) and file.lower().endswith((".mp3", ".wav", ".amr", ".m4a", ".mid", ".ogg"))
    
    def isVideo(self, file):
        return os.path.isfile(file) and file.lower().endswith((".mp4", ".flv", ".mkv", ".avi", ".mpg"))
        
    def openFile(self, file):
        if self.isVideo(file):
            self.setCurrent(self.videoControl)
            self.videoControl.Play(file)
        elif self.isAudio(file):
            self.setCurrent(self.audioControl)
            self.audioControl.Play(file)
        
    def setCurrent(self, form):
        if self.form is not None:
            self.form.unpack()
        form.pack(expand_x=YES, expand_y=YES)
        self.form = form
        
if __name__ == "__main__":
    Aeon().run()
import os
from eyed3 import load as loadAudioFile
from mutagen import File as AudioFile


def getTrackInfo(track):
    artist = "Unkown artist"
    album = "Unkown album"
    title = os.path.split(track)[1]
    try:
        audio = loadAudioFile(track)
        artist = audio.tag.artist
        album = audio.tag.album
        title = audio.tag.title
    except Exception as err:
        print("ERROR:", err)
    if artist is None:
        artist = "Unkown artist"
    if album is None:
        album = "Unkown album"
    if title is None:
        title = os.path.split(track)[1]
    return artist, album, title, AudioFile(track).info.length

def getAlbumArt(track):
    for art in os.listdir("./././data/art/"):
        os.remove(os.path.join("./././data/art/", art))
    try:
        audio = loadAudioFile(track)
        for image in audio.tag.images:
            with open("./././data/art/FRONT_COVER.jpg", "wb") as fh:
                fh.write(image.image_data)
        return "./././data/art/FRONT_COVER.jpg" if len(os.listdir("./././data/art/")) else None
    except Exception as err:
        print("Error loading artwork:", err)
        return None
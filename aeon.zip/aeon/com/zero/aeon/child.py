import pygame, os
from pygame.locals import *
from .const import *
from .tags import getTrackInfo


class Child:

    def __init__(self, parent, fg1=WHITE, fg2=BLACK, bg1=SILVER, bg2=GREEN, size_hint=(None, None)):
        self.parent = parent
        self.screen = parent.screen
        
        self.bg1 = bg1
        self.bg2 = bg2
        self.bg = self.bg1
        
        self.fg1 = fg1
        self.fg2 = fg2
        self.fg = fg1
        
        self.size_hint = size_hint
        self.size = (0, 0)
        self.pos = self.x, self.y = (0, 0)
        
        self.name = self.__class__.__name__   
        self.toplevel = True     
        self.children = []
        
        self.ipadx = self.ipady = self.padx = self.pady = 0
        
    def config(self, properties):
        for property, value in properties.items():
            setattr(self, property, value)
        
    def addChild(self, child):
        child.child_pos = len(self.children)
        self.children.append(child)
        
    def removeChild(self, child):
        self.children.remove(child)
        
    def getRoot(self):
        parent = self.parent
        while True:
            if hasattr(parent, "ROOT"):
                return parent
            parent = parent.parent
        
    def pack(self, side=CENTER, expand_x=NO, expand_y=NO):
        self.config({"side": side, "expand_x": expand_x, "expand_y": expand_y})
        self.parent.addChild(self)
        
    def unpack(self):
        self.parent.removeChild(self)
        
    def keyDown(self, key, char):
        for child in self.children:
            child.keyDown(key, char)
            
    def keyUp(self, key):
        for child in self.children:
            child.keyUp(key)
            
    def mouseDown(self, pos, btn, double_click):
        for child in self.children:
            child.mouseDown(pos, btn, double_click)
            
    def mouseUp(self, pos, btn):
        for child in self.children:
            child.mouseUp(pos, btn)
            
    def mouseMoved(self, pos):
        for child in self.children:
            child.mouseMoved(pos)
            
    def mouseDragged(self, pos):
        for child in self.children:
            child.mouseDragged(pos)
            
    def isHovering(self):
        x, y = pygame.mouse.get_pos()
        return x > self.x and x < self.x + self.size[0] and y > self.y and y < self.y + self.size[1]
    
    def getchild(self, child_pos):
        if child_pos < 0:
            return None
        try:
            return self.children[child_pos]
        except IndexError:
            return None
        
    def draw(self):
        for child in self.children:
            child.draw()
            
    def initDraw(self):        
        # calculate Child size
        if self.size_hint[0] is None:
            self._w = self.parent.size[0]
        else:
            self._w = self.size_hint[0]
        if self.size_hint[1] is None:
            self._h = self.parent.size[1]
        else:
            self._h = self.size_hint[1]
            
        self.size = (self._w-self.padx, self._h-self.pady)
        
        if hasattr(self, "image"):
            self.size = self.image.get_size()
        
        # calculate Child position
        if self.side == CENTER:
            self.x = self.parent.x + self.parent.size[0] // 2 - self.size[0] // 2
            self.y = self.parent.y + self.parent.size[1] // 2 - self.size[1] // 2
        elif self.side == LEFT:
            obj = self.parent.getchild(self.child_pos-1)
            if obj is not None and obj.side == LEFT: ipadx = obj.x + obj.size[0] + 1
            else: ipadx = 1
            self.x = self.parent.x + self.ipadx + ipadx
            self.y = self.parent.y + self.parent.size[1] / 2 - self.size[1] / 2 + self.ipady - 1
        elif self.side == RIGHT:
            obj = self.parent.getchild(self.child_pos-1)
            if obj is not None and obj.side == RIGHT: ipadx = obj.size[0] + 1 #obj.x + obj.size[0] + 1
            else: ipadx = 1
            self.x = self.parent.x + self.parent.size[0] - self.size[0] - self.ipadx - ipadx
            self.y = self.parent.y + self.parent.size[1] / 2 - self.size[1] / 2 + self.ipady - 1
        elif self.side == TOP:
            obj = self.parent.getchild(self.child_pos-1)
            if obj is not None and obj.side == TOP: ipady = obj.size[1] + 1
            else: ipady = 0
            self.x = self.parent.x + self.parent.size[0] // 2 - self.size[0] // 2
            self.y = self.parent.y + 1 + ipady + self.ipady
        elif self.side == BOTTOM:
            obj = self.parent.getchild(self.child_pos-1)
            if obj is not None and obj.side == BOTTOM: ipady = obj.size[1] #+ 1
            else: ipady = 1
            self.x = self.parent.x + self.parent.size[0] // 2 - self.size[0] // 2
            self.y = self.parent.y + self.parent.size[1] - self.size[1] - ipady - self.ipady
        
        self.pos = (self.x, self.y)
        
class Panel(Child):
    
    def __init__(self, *args, **kwargs):
        super(Panel, self).__init__(*args, **kwargs)
        
    def draw(self):
        self.initDraw()
        pygame.draw.rect(self.screen, self.bg, (*self.pos, *self.size))
        
        super().draw()
        
class Image(Child):
    
    def __init__(self, parent, source, auto_resize=False, size_hint=(610, 610)):
        super(Image, self).__init__(parent)
        self._image = pygame.image.load(source).convert_alpha()
        if auto_resize:
            self.resize(size_hint)
        self.image = self._image.copy()
        self.auto_resize = auto_resize
        
    def getColor(self):
        w, h = self.image.get_size()
        for x in range(w):
            for y in range(h):
                if x == w // 2 and y == h // 2:
                    return self.image.get_at((x, y))
        
    def resize(self, size_hint=(610, 610)):
        self.image = pygame.transform.scale(self._image, size_hint)
        
    def draw(self):
        self.initDraw()
        if self.auto_resize:
            self.resize(self.parent.size)
        w, h = self.image.get_size()
        self.screen.blit(self.image, (self.x, self.y))
        
class Text(Child):
    
    def __init__(self, parent, text="", height=18, fg1=WHITE, fg2=SILVER, bg1=SILVER, bg2=SILVER, align=CENTER):
        self.font = pygame.font.SysFont("Calibri", 18, bold=True)
        super(Text, self).__init__(parent, fg1=fg1, fg2=fg2, bg1=bg1, bg2=bg2, size_hint=(self.font.render(" " + text + " ", True, WHITE).get_width(), height))
        
        self.text = text
        self.align = align
        
    def setValue(self, value):
        self.text = value
        
    def draw(self):
        self.initDraw()
        pygame.draw.rect(self.screen, self.bg, (*self.pos, *self.size))
        
        text = self.font.render(self.text, True, self.fg)
        w, h = text.get_size()
        
        if self.align == CENTER:
            x = self.x + self.size[0] // 2 - w // 2
            y = self.y + self.size[1] // 2 - h // 2
        elif self.align == LEFT:
            x = self.x + 2
            y = self.y + self.size[1] // 2 - h // 2
        elif self.align == RIGHT:
            x = self.x + self.size[0] - w - 2
            y = self.y + self.size[1] // 2 - h // 2
            
        self.screen.blit(text, (x, y))

class tListItem(Child):
    
    def __init__(self, parent, text, icon, split):
        super(tListItem, self).__init__(parent)
        self.index = len(self.parent.items)
        self.track = text
        self.text = os.path.split(text)[1]
        self.icon = pygame.transform.scale(pygame.image.load(icon).convert_alpha(), (25, 25))
        self.split = split
        
        if self.split:
           self.artist, self.album, self.title = getTrackInfo(self.track)

        self.fg1 =  WHITE
        self.fg2 = BLACK
        self.fg = self.fg1

        self.bg1 =  GREY
        self.bg2 = GREEN
        self.bg = self.bg1

        self.x = self.y = 0

    def mouseMoved(self, pos):
        x, y = pos
        if x > self.x and x < self.x + self.parent.size[0] and y > self.y and y < self.y + 35:
            self.grab()
        else:
            self.ungrab()

        if self.parent.selected is not None:
            self.parent.selected.grab()

    def mouseDown(self, pos, btn, double_click):
        if btn == 1:
            x, y = pos
            if x > self.x and x < self.x + self.parent.size[0] and y > self.y and y < self.y + 35:
                self.parent.ungrabAll()
                self.grab()
                self.parent.index = self.offset

    def grab(self):
        self.fg = self.fg2
        self.bg = self.bg2

    def ungrab(self):
        self.fg = self.fg1
        self.bg = self.bg1

    def draw(self, index):
        self.y =  self.parent.y + index * 35 + 1
        if self.index >= 1:
            self.y += index * 1
        self.x = self.parent.x + 1
        pygame.draw.rect(self.screen, self.bg, (self.x, self.y, self.parent.size[0] - 2, 35))        
        self.screen.blit(self.icon, (self.x, self.y + 3))
        
        if self.split:            
            title = self.parent.font.render(self.title, True, self.fg)
            label = self.parent.font.render(self.artist + " - " + self.album, True, self.fg)
            self.screen.blit(title, (self.x + 30, self.y + 6))
            self.screen.blit(label, (self.x + 30, self.y + 20))
        else:
            text = self.parent.font.render(self.text, True, self.fg)
            self.screen.blit(text, (self.x + 30, self.y + 10))
            
class List(Child):
    
    def __init__(self, parent, fun1=None, fun2=None):
        super(List, self).__init__(parent, bg1=SILVER)
        self.fun1 = fun1
        self.fun2 = fun2
        self.font = pygame.font.SysFont("Calibri", 15, "bold")
        self.items = []

        self.start = 0
        self.end = 0

        self.index = 0
        self.selected = None

    def mouseMoved(self, pos):
        for item in self.items:
            item.mouseMoved(pos)

    def mouseDown(self, pos, btn, double_click):
        for item in self.items:
            item.mouseDown(pos, btn, double_click)

    def keyDown(self, key, char):
        if key == K_DOWN:
            self.scroll()
        elif key == K_UP:
            self.scroll(UP)
        elif key == K_RETURN:
            if self.fun1 is not None:
                self.fun1(self.selected.track)

    def ungrabAll(self):
        for item in self.items:
            item.ungrab()

    def scroll(self, direction=DOWN):
        if not self.items:
            return

        self.ungrabAll()

        if direction == DOWN:
            x = self.index + 1
            self.index = x if x <= len(self.items)-1 else len(self.items)-1
        elif direction == UP:
            x = self.index - 1
            self.index = x if x >= 0 else 0

        self.selected = self.items[self.index]
        self.selected.grab()

        if direction == DOWN and self.selected is not None:
            can_scroll = self.index >= self.start + self.size[1] // 35 - 1
            more_items = len(self.items) - self.selected.index + 1 > 0

            if can_scroll and more_items:
                self.start += 1
        elif direction == UP and self.selected is not None:
            can_scroll = self.selected.offset <= 0
            more_items = self.selected.index > 0

            if can_scroll and more_items:
                self.start -= 1

    def insert(self, text, icon=None, split=False):
        self.items.append(tListItem(self, text, icon, split))
        self.items.sort(key=lambda item: os.path.isfile(item.track))

    def draw(self):
        self.initDraw()
        pygame.draw.rect(self.screen, self.bg, (*self.pos, *self.size))
        a = self.start
        b = a + self.size[1] // 35 - 1
        for index, item in enumerate(self.items[a:b]):
            item.offset = index
            item.draw(index)
            
class Button(Child):
    
    def __init__(self, parent, text="", image1=None, image2=None, size_hint=(30, 20), fg1=None, fg2=None, bg1=None, bg2=None, fun=None):
        if image1 is not None:
            size_hint = pygame.image.load(image1).convert_alpha().get_size()
        super(Button, self).__init__(parent, size_hint=size_hint, bg1=bg1, bg2=bg2)
        self.text = text
        self.fg1 = fg1 if fg1 is not None else WHITE
        self.fg2 = fg2 if fg2 is not None else GREEN

        self.bg1 = bg1 if bg1 is not None else BLACK
        self.bg2 = bg2 if bg2 is not None else BLACK

        self.font = pygame.font.SysFont("Calibri", 15, "bold")

        self.fg = self.fg1
        self.bg = self.bg1

        self.image1 = pygame.image.load(image1) if image1 is not None else image1
        self.image2 = pygame.image.load(image2) if image2 is not None else image2
        self._image = self.image1

        #pygame.image.save(pygame.image.load("data/image/pause.png").convert_alpha().subsurface(4, 4, 17, 17), "pause2.png")

        self.fun = fun
        #self.w, self.h = self.font.render(self.text, True, self.fg).get_size()

    def mouseDown(self, pos, btn, double_click):
        x, y = pos
        if x > self.x and x < self.x + self.size[0] and y > self.y and y < self.y + self.size[1] and self.fun is not None:
            # self.fg = self.fg2
            self.fun()

    def draw(self):
        self.initDraw()
        if self.image1 is None:
            pygame.draw.rect(self.screen, self.bg, (*self.pos, *self.size))
            text = self.font.render(self.text, True, self.fg)
            w, h = text.get_size()
            self.screen.blit(text, (self.x + self.size[0] / 2 - w / 2, self.y + self.size[1] / 2 - h / 2))
        else:
            w, h = self._image.get_size()
            self.screen.blit(self._image, (self.x + self.size[0] / 2 - w / 2, self.y + self.size[1] / 2 - h / 2))

class Slider(Child):

    def __init__(self, parent, size_hint=(None, 5), value=0, _from=0, to=100, fg1=GREEN, bg1=WHITE):
        super(Slider, self).__init__(parent, size_hint=size_hint, fg1=fg1, bg1=bg1)
        self.parent = parent

        self._from = _from
        self.to = to
        self.value = value
        self.canShow = False

    def mouseMoved(self, pos):
        if self.isHovering():
            self.canShow = True
        else:
            self.canShow = False

    def setValue(self, value):
        self.value = value

    def getValue(self):
        return self.value

    def draw(self):
        self.initDraw()
        self.pos = (self.x, self.y - 8)
        pygame.draw.rect(self.screen, self.bg, (*self.pos, *self.size))
        if self.value > 0:
            pygame.draw.rect(self.parent.screen, self.fg, (*self.pos, (self.value / self.to) * self.size[0], self.size[1]))

        #if self.canShow:
         #   pygame.draw.circle(self.screen, self.fg, (self.x + (self.value / self.to) * self.size[0], self.y + 3), 9)
            
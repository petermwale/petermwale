import pyglet, sys, os
from com.zero.aeon.child import *
from com.zero.aeon.const import *
from com.zero.aeon.app import App
from com.zero.aeon.form import Form
from com.zero.aeon.file import File
from com.zero.aeon.movie import Movie
from com.zero.aeon.tags import getAlbumArt, getTrackInfo
from com.zero.aeon.manager import Manager


class MediaForm(Form):
    
    def __init__(self, parent):
        super(MediaForm, self).__init__(parent)
        
        def openFile(file=None):
            if file is None:
                if self.listBox.selected is None:
                    return
                file = self.listBox.selected.track
                
            if not self.parent.mediaList:
                self.parent.media_index = 0
                self.parent.mediaList.append(file)
            else:
                if file not in self.parent.mediaList:
                    self.parent.mediaList.append(file)
                    self.parent.media_index += 1
                    
            self.getRoot().openFile(file)
            self.getRoot().now_playing = self.parent
            self.ungrab()
        
        self.setTitle("Songs {0} {1}".format("by" if self.parent.name.startswith("artist") \
            else "from", self.parent.listBox.selected.text))    
        
        self.listBox = List(self.container, fun1=openFile)  
        self.listBox.pack(side=TOP, expand_x=YES, expand_y=YES)
        
        for song, artist, album, title in self.parent.media_list.get(self.parent.listBox.selected.text):
            self.listBox.insert(song, "data/image/audio.png", True, artist, album, title)
            
        panel = Panel(self, bg1=SILVER, size_hint=(None, 20))
        panel.config({"ipadx": 1, "padx": 1})
        panel.pack(side=BOTTOM, expand_x=YES)
        
        btn = Button(panel, text="Cancel", size_hint=(35, 15), fun=self.destroy)
        btn.config({"ipadx": 4})
        btn.pack(side=RIGHT)
        
        btn = Button(panel, text="Play", size_hint=(30, 15), fun=openFile)
        btn.config({"ipadx": 7})
        btn.pack(side=RIGHT)
         
class MediaList(Panel):
    
    def __init__(self, parent, name="Media"):
        super(MediaList, self).__init__(parent)
        
        self.manager = Manager()
        self.media_list = []
        self.media_index = 0
        
        label = Text(self, text=name, fg1=BLACK)
        label.pack(side=TOP, expand_x=YES)
        
        def openFile(file=None):
            if file is None:
                if self.listBox.selected is None:
                    return
                file = self.listBox.selected.track
            self.getRoot().openFile(file)  
            self.getRoot().now_playing = self
            
        def show(file):
            if self.listBox.selected is not None:
                MediaForm(self).show()
        
        self.listBox = List(self, fun1=openFile if self.name.startswith(("audio", "video")) else show)
        self.listBox.pack(side=TOP, expand_x=YES, expand_y=YES)
        
        panel = Panel(self, bg1=SILVER, size_hint=(None, 18))
        panel.pack(side=BOTTOM, expand_x=YES)  
        
        def switch():
            if self.getRoot().audioControl.player.playing:
                self.getRoot().setCurrent(self.getRoot().audioControl)
            elif self.getRoot().videoControl.movie.player.playing:
                self.getRoot().setCurrent(self.getRoot().videoControl)    
                
        btn = Button(panel, text="Play", size_hint=(25, 15), fun=openFile)
        btn.pack(side=LEFT) 
        
        btn = Button(panel, text="~", size_hint=(20, 15), fun=switch)
        btn.pack(side=LEFT)        
        
        btn = Button(panel, text="::", size_hint=(20, 15), fun=lambda: self.getRoot().setCurrent(self.getRoot().pager))
        btn.pack(side=RIGHT)       
        
        if self.name.startswith("media"): 
            btn = Button(panel, text="+", size_hint=(15, 15), fun=File(self, fun=self.openFile).show)
            btn.config({"ipadx": 1})
            btn.pack(side=RIGHT)
        elif self.name.startswith(("audio", "video")):
            btn = Button(panel, text="-", size_hint=(15, 15), fun=self.delete)
            btn.config({"ipadx": 1})
            btn.pack(side=RIGHT)
        
    def dropFile(self, file):
        if self.getRoot().isAudio(file) or self.getRoot().isVideo(file):
            self.openFile(file)
            
    def delete(self):
        if self.listBox.selected is not None:
            self.manager.delete(self.listBox.selected.track)
            self.refresh()
        
    def openFile(self, file=None):
        if file not in self.media_list:
            self.addMedia(file)
        self.getRoot().openFile(file)  
        self.getRoot().now_playing = self     
        
    def addMedia(self, file):
        if file not in self.media_list:
            self.media_list.append(file)
            self.listBox.insert(file, "data/image/audio.png" if self.getRoot().isAudio(file) else "data/image/video.png")
            self.manager.create()
            
            if self.getRoot().isAudio(file):
                artist, album, title, length = getTrackInfo(file)
                self.manager.add(file, "audio", artist, album, title)
            else:
                self.manager.add(file, "video")
            
        for index, media in enumerate(self.media_list):
            if media == file:
                self.media_index = index                   
    
    def getMedia(self):
        return self.media_list 
        
    def getNextMedia(self):
        if not self.media_list:
            return None
        x = self.media_index + 1
        self.media_index = x if x <= len(self.media_list)-1 else 0
        return self.media_list[self.media_index] if self.name.startswith("media") else \
            self.media_list[self.media_index][0]
    
    def getPrevMedia(self):
        if not self.media_list:
            return None
        x = self.media_index - 1
        self.media_index = x if x >= 0 else len(self.media_list)-1
        return self.media_list[self.media_index] if self.name.startswith("media") else \
            self.media_list[self.media_index][0]   
    
    def keyDown(self, key, char):
        if key == K_a and self.getRoot().audioControl.player.source:
            self.getRoot().setCurrent(self.getRoot().audioControl) 
        elif key == K_v and self.getRoot().videoControl.movie.player.source:
            self.getRoot().setCurrent(self.getRoot().videoControl)  
        super().keyDown(key, char)                   
         
class AudioList(MediaList):
     
    def __init__(self, parent, label="Songs"):
         super(AudioList, self).__init__(parent, label)
         self.media_list = self.getMedia()
         
    def getMedia(self):
        data = self.manager.get()
        if data is not None:
            files = []
            for media, info in data.items():
                kind, artist, album, title = info
                if self.name.startswith(kind) and media not in files and os.path.exists(media):
                    files.append((media, artist, album, title))
                if not os.path.exists(media):
                    self.manager.delete(media)
            return files
        else:
            return self.media_list 
         
    def refresh(self):
        self.media_list = self.getMedia()
        self.listBox.clear()
        for media, artist, album, title in self.media_list:
            if self.getRoot().isAudio(media):
                self.listBox.insert(media, "data/image/audio.png" , True, artist, album, title)
            else:
                self.listBox.insert(media, "data/image/video.png")
            
class VideoList(AudioList):
     
    def __init__(self, parent):
         super(VideoList, self).__init__(parent, "Videos")
    
class ArtistList(MediaList):
     
    def __init__(self, parent, label="Artists"):
         super(ArtistList, self).__init__(parent, label)
         self.mediaList = []
         self.media_list = {}
         self.media_index = None
         
    def getMedia(self):
        data = self.manager.get()
        files = {}
        if data is not None:
            for media, info in data.items():
                kind, artist, album, title = info
                if kind == "video":
                    continue
                tag = artist if self.name.startswith("artist") else album
                if tag not in files:
                    files[tag] = []
                if media not in files.values():
                    files[tag].append((media, artist, album, title))
        return files
        
    def getNextMedia(self):
        if not self.mediaList:
            return None
        x = self.media_index + 1
        self.media_index = x if x <= len(self.mediaList)-1 else 0
        return self.mediaList[self.media_index]
    
    def getPrevMedia(self):
        if not self.mediaList:
            return None
        x = self.media_index - 1
        self.media_index = x if x >= 0 else len(self.mediaList)-1
        return self.mediaList[self.media_index]
    
    def refresh(self):
        self.listBox.clear()
        for tag, songs in self.getMedia().items():
            self.media_list[tag] = songs
            self.listBox.insert(tag, "data/image/icon.png")
    
class AlbumList(ArtistList):
     
    def __init__(self, parent):
         super(AlbumList, self).__init__(parent, "Albums")
 
class Controls(Panel):
        
    def __init__(self, parent):
        super(Controls, self).__init__(parent, size_hint=(None, 45))
        
        panel = Panel(self, bg1=SILVER, size_hint=(None, 20))
        panel.pack(expand_x=YES)
        
        btn = Button(panel, image1="data/image/prev.png", fun=self.parent.goPrev)
        btn.config({"ipadx": 1})
        btn.pack(side=LEFT)
        
        self.btnPlay = Button(panel, image1="data/image/pause.png", fun=self.parent.play)
        self.btnPlay.config({"ipadx": 1})
        self.btnPlay.pack(side=LEFT)
        
        btn = Button(panel, image1="data/image/next.png", fun=self.parent.goNext)
        btn.config({"ipadx": 2})
        btn.pack(side=LEFT)
        
        self.ellapsed = Text(panel, text="00:00", fg1=BLACK)
        self.ellapsed.config({"ipadx": 2})
        self.ellapsed.pack(side=LEFT)
        
        self.seeker = Slider(panel, fg1=GREEN, fun=self.parent.seek)
        self.seeker.pack(side=LEFT, expand_x=YES)
        
        def show():
            self.getRoot().setCurrent(self.getRoot().now_playing)
            pygame.mouse.set_visible(True)
        
        btn = Button(panel, text="::", size_hint=(20, 15), fun=show)
        btn.config({"ipadx": 2})
        btn.pack(side=RIGHT)
        
        btn = Button(panel, image1="data/image/vol.png", fun=lambda: self.parent.volumeControl.config({"count": 0}))
        btn.config({"ipadx": 2})
        btn.pack(side=RIGHT)
        
        self.duration = Text(panel, text="00:00", fg1=BLACK)
        self.duration.config({"ipadx": 3})
        self.duration.pack(side=RIGHT)
        
        self.count = 0
        
    def keyDown(self, key, char):
        if key == K_SPACE:
            self.parent.play()
        elif key == K_p:
            self.parent.goPrev()
        elif key == K_n:
            self.parent.goNext()
        
    def draw(self):
        self.count += 1
        if self.count < 200 or self.isHovering():
            super().draw()
            pygame.mouse.set_visible(True)
        else:
            pygame.mouse.set_visible(False)

class VolumeControl(Panel):
    
    def __init__(self, parent):
        super(VolumeControl, self).__init__(parent, bg1=BLACK, size_hint=(250, 250), border=0)  
        
        panel = Panel(self, bg1=GREY, border=3)
        panel.config({"ipadx": -1, "padx":-3, "ipady":-1, "pady":-3})
        panel.pack(expand_x=YES, expand_y=YES)
        
        self.level = 50
        self.label = Info(self, text="50%", fg1=SILVER, height=100)
        self.label.pack()
        
        self.count = 200
        
        def setVolume(val):
            if val * 100 > self.level:
                self.setVolume(1)
            elif val * 100 < self.level:
                self.setVolume(-1)            
        
        self.slider = Slider(self, fg1=GREY, bg1=SILVER, size_hint=(None, 9), value=50, to=100, fun=setVolume)
        self.slider.config({"ipadx": 5, "padx": 6, "ipady": 5})
        self.slider.pack(side=BOTTOM, expand_x=YES)
        
    def setVolume(self, level):
        if level > 0:
            x = self.level + 5
            self.level = x if x <= 100 else 100
        elif level < 0:
            x = self.level - 5
            self.level = x if x >= 0 else 0
        if self.parent.name.startswith("audio"):
            self.parent.player.volume = self.level / 100
        elif self.parent.name.startswith("video"):
            self.parent.movie.player.volume = self.level / 100
            
        self.slider.setValue(self.level)
        self.label.setValue(f"{self.level} %")
        self.count = 0
        
    def keyDown(self, key, char):
        if self.count < 200:
            super().keyDown(key, char)
        
    def draw(self):
        self.count += 1
        if self.count < 200:
            super().draw()
                     
class MediaControl(Panel):
    
    def __init__(self, *args, **kwargs):
        super(MediaControl, self).__init__(*args, **kwargs)
        
        self.volumeControl = VolumeControl(self)        
        self.controls = Controls(self)
        self.album_art = "image"
        
    def goPrev(self):
        media = self.getRoot().now_playing.getPrevMedia()
        if media is not None:
            self.getRoot().openFile(media)
    
    def goNext(self):
        media = self.getRoot().now_playing.getNextMedia()
        if media is not None:
            self.getRoot().openFile(media)                     
        
    def mouseMoved(self, pos):
        self.controls.count = 0
        
    def mouseDown(self, pos, btn, double_click):
        if double_click:
            self.getRoot().switchFullscreen()
        super().mouseDown(pos, btn, double_click)
    
    def keyDown(self, key, char):
        if key == K_f:
            self.getRoot().switchFullscreen()
        elif key == K_UP and not self.name.startswith("media"):
            self.volumeControl.setVolume(1)
        elif key == K_DOWN and not self.name.startswith("media"):
            self.volumeControl.setVolume(-1)
        elif key == K_m:
            self.getRoot().setCurrent(self.getRoot().now_playing)
            pygame.mouse.set_visible(True)
        elif key == K_v and self.name.startswith("audio"):
            if self.album_art == "image":
                self.album_art = "vinyl"
            elif self.album_art == "vinyl":
                self.album_art = "image"
                
            if self.album_art == "vinyl":
                self.children[self.art.child_pos] = Vinyl(self, self.album_art_path)
                self.children[self.art.child_pos].resize()
                self.config({"bg": self.children[self.art.child_pos].getColor()})
            elif self.album_art == "image":
                self.children[self.art.child_pos] = Image(self, self.album_art_path)
                self.children[self.art.child_pos].resize()
                self.config({"bg": self.children[self.art.child_pos].getColor()})
        super().keyDown(key, char)
        
    def dropFile(self, file):
        self.getRoot().openFile(file)

class AudioControl(MediaControl):
     
    def __init__(self, parent):
        super(AudioControl, self).__init__(parent)
        
        self.player = pyglet.media.Player() 
               
        self.art = Image(self, "data/image/art.png")
        self.art.resize()
        self.art.pack(expand_x=YES, expand_y=YES)
        
        self.label = Info(self, fg1=BLACK, align=LEFT)
        self.label.config({"force_color": False})
        self.label.pack(side=TOP, expand_x=YES)
                
        self.config({"bg": self.art.getColor()})
        self.controls.pack(side=BOTTOM, expand_x=YES)
        self.volumeControl.pack()
        self.playback_paused = False
        
    def Play(self, file):
        if self.player.playing:
            self.player.pause()
            
        self.player = pyglet.media.Player()
        source = pyglet.media.load(file)
        
        self.info = getTrackInfo(file)
        self.info_index = 0        
        self.trackLength = self.info[-1]
        
        self.player.queue(source)
        self.player.play()
        self.playback_paused = False
        
        if self.getRoot().videoControl.movie.player.playing:
            self.getRoot().videoControl.movie.player.pause()
        
        self.controls.btnPlay.config({"image": pygame.image.load("data/image/pause.png").convert_alpha()})        
        self.getRoot().setTitle("{0} | Aeon Media Player".format(os.path.split(file)[1]))
        self.controls.seeker.config({"to": self.trackLength})
        
        self.album_art_path = getAlbumArt(file)        
        self.children[self.art.child_pos] = Vinyl(self, self.album_art_path) if \
            self.album_art == "vinyl" else Image(self, self.album_art_path)
        self.children[self.art.child_pos].resize()
        self.config({"bg": self.children[self.art.child_pos].getColor()})
            
    def play(self):
        if self.player.source and not self.player.playing:
            self.player.play()
            self.controls.btnPlay.config({"_image": pygame.image.load("data/image/pause.png").convert_alpha()})
            self.playback_paused = False
        elif self.player.source and self.player.playing:
            self.player.pause()
            self.controls.btnPlay.config({"_image": pygame.image.load("data/image/play.png").convert_alpha()})
            self.playback_paused = True

    def seek(self, val):
        
        def get_decimal_points(num):
            index = str(num).rfind(".")
            if index == -1:
                return 0
            return len(str(num)[index + 1:])
        
        if self.player.source:
            pos = round(val * self.trackLength, get_decimal_points(self.trackLength))
            print(pos, "of", self.trackLength)
            self.player.seek(pos)
        
    def draw(self):
        super().draw()
        
        if self.player.source and self.player.time > self.trackLength and not self.playback_paused:
            self.goNext()
        
        if not self.player.playing:
            return
        
        if pygame.time.get_ticks() % 1300 == 0:
            x = self.info_index + 1  
            self.info_index = x if x < 3 else 00
            
        if pygame.time.get_ticks() % 3 == 0:
            self.children[self.art.child_pos].rotate()
                  
        self.label.setValue(self.info[:3][self.info_index])
        
        Min, Sec = divmod(self.player.time, 60)
        Hour, Min = divmod(Min, 60)
    
        Sec = str(int(Sec))
        Min = str(int(Min))
        Hour = str(int(Hour))
            
        if len(Sec) < 2:
            Sec = "0" + Sec
        if len(Min) < 2:
            Min = "0" + Min
        if len(Hour) < 2:
            Hour = "0" + Hour + ":"
            
        if self.trackLength < 60 ** 2:
            self.controls.ellapsed.config({"ipadx": 2})
            self.controls.duration.config({"ipadx": 3})
            self.controls.seeker.config({"padx": 191, "ipadx": 1})
            Hour = ""
        else:
            self.controls.ellapsed.config({"ipadx": 8})
            self.controls.duration.config({"ipadx": 9})
            self.controls.seeker.config({"padx": 220, "ipadx": 10})
                
        self.controls.ellapsed.setValue(Hour + Min + ":" + Sec)
        
        Min, Sec = divmod(self.trackLength-self.player.time, 60)
        Hour, Min = divmod(Min, 60)
            
        Sec = str(int(Sec))
        Min = str(int(Min))
        Hour = str(int(Hour))
            
        if len(Sec) < 2:
            Sec = "0" + Sec
        if len(Min) < 2:
            Min = "0" + Min
        if len(Hour) < 2:
            Hour = "0" + Hour + ":"
            
        if self.trackLength < 60 ** 2:Hour = ""
                
        self.controls.duration.setValue("-" + Hour + Min + ":" + Sec)       
        self.controls.seeker.setValue(self.player.time)       
        self.art.rotate() 
        #self.getRoot().timer.bind(tick, 1)
 
class VideoControl(MediaControl):
     
    def __init__(self, parent):
        super(VideoControl, self).__init__(parent)
         
        self.movie = Movie(self)
        self.movie.pack(expand_x=YES, expand_y=YES)
        
        self.controls.pack(side=BOTTOM, expand_x=YES)
        self.volumeControl.pack()
        
        self.playback_paused = False
         
    def Play(self, file):
        self.movie.play(file)
        
    def play(self):
        if self.movie.player.source and not self.movie.player.playing:
            self.movie.player.play()
            self.controls.btnPlay.config({"_image": pygame.image.load("data/image/pause.png").convert_alpha()})
            self.playback_paused = False
        elif self.movie.player.source and self.movie.player.playing:
            self.movie.player.pause()
            self.controls.btnPlay.config({"_image": pygame.image.load("data/image/play.png").convert_alpha()})
            self.playback_paused = True

    def seek(self, val):
        
        def get_decimal_points(num):
            index = str(num).rfind(".")
            if index == -1:
                return 0
            return len(str(num)[index + 1:])
        
        if self.movie.player.source:
            pos = round(val * self.movie.videoLength, get_decimal_points(self.movie.videoLength))            
            print(pos, "of", self.movie.videoLength)
            self.movie.player.seek(pos)
                
class Page(Image):
    
    def  __init__(self, parent, source, page_name, form=None):
        super(Page, self).__init__(parent, source=source)
        
        self.page_name = page_name     
        self.form = form   
        self.side = CENTER
        self.expand_x = self.expand_y = YES
        
    def mouseDown(self, pos, btn, doucle_click):
        if btn == LEFT_CLICK and self.isHovering() and self.form is not None:
            self.getRoot().setCurrent(self.form)
        
    def mouseMoved(self, pos):
        if self.isHovering():
            self.resize((610, 610))
            self.parent.label.setValue("Tap to goto {0}".format(self.page_name))
        else:
            self.resize((350, 350))
            self.parent.label.setValue("")
        
class Pager(Panel):
    
    def __init__(self, parent):
        super(Pager, self).__init__(parent, bg1=SILVER)
              
        media = Page(self, "data/image/media.jpg", "Media", self.getRoot().mediaList)
        songs = Page(self, "data/image/songs.png", "Songs", self.getRoot().audioList)
        artists = Page(self, "data/image/artist.png", "Artists", self.getRoot().artistList)
        albums = Page(self, "data/image/album.png", "Albums", self.getRoot().albumList)
        #playlists = Page(self, source="data/image/media.jpg", page_name="Playlists")
        videos = Page(self, "data/image/movie.jpg", "Videos", self.getRoot().videoList)
        about = Page(self, "data/image/info.png", "About", self.getRoot().about)
        
        self.pages = [media, songs, artists, albums, videos, about]
        self.index = 0
        
        for page in self.pages:
            page.resize((350, 350))
            
        self.label = Text(self, fg1=BLACK, bg1=SILVER, align=LEFT)
        self.label.pack(side=BOTTOM, expand_x=YES)
        
    def keyDown(self, key, char):
        if key == K_LEFT:
            x = self.index - 1
            self.index = x if x >= 0 else 0
        elif key == K_RIGHT:
            x = self.index + 1
            self.index = x if x <= len(self.pages)-1 else len(self.pages)-1
            
    def mouseDown(self, pos, btn, double_click):
        self.pages[self.index].mouseDown(pos, btn, double_click)
            
    def mouseMoved(self, pos):
        self.pages[self.index].mouseMoved(pos)
            
    def draw(self):
        self.initDraw()
        pygame.draw.rect(self.screen, self.bg, (*self.pos, *self.size))
        self.pages[self.index].draw()
        self.label.draw()

class About(Panel):
    
    def __init__(self, parent):
        super(About, self).__init__(parent, bg1=GREEN)
        
        user_name = os.environ["USERNAME"] if sys.platform.startswith("win") else os.environ["USER"]
        
        text = [
            "Welcome to *Aeon Media Player*", "", "",
            "LICENCE",
            f"This Software is licenced to *{user_name}* and you can share with your friends!",
            "*Aeon Media Player* is meant to be a small & light-weight media player, much like VLC!",
            "This Software was written by *Peter Mwale* using the PYTHON (visit 'http://python.org' for more info) programming language.",
            "I made use of the following PYTHON libraries: PYGAME ('http://pygame.org') for the GUI, PYGLET ('http://pyglet.org')",
            "for audio & video playback, EYED3 ('http://eyed3.org') and MUTAGEN ('http://mutagen.org') for extracing audio metadata.",
            "The source code of this software if FREE to use and/or modify (Open Source) [as long as you dont take credit for yourself],",
            "and may be found on github.", "", "",
            "USAGE", "For the basic usage of this app, please read the *README.TXT* file which should come together",
            "with this software. If you want to get familiar with the app or other features, please hit F5 or click the [?] to",
            "open the guide in your Web Browser.","", "",
            "CREDIT", "Here is a list of websites from which i downloaded images used in this software:",
            "'http://pngtree.com'", "I do not take credit for the images i have used in anyway.", "", ""
            "CONTACTS", "You can always find me on the following platforms:",
            "Facebook: tony wat/ip man, Email: peteraugustinemwale@gmail.com, Github: @petermwale,",
            "Call/SMS/WhatsApp: +265997696464 / +265888732209 (not. on WhatsApp)", "", ""
            "Courtesy of Sub-Zero Inc. Copyright 2021. By Peter Mwale"
            ]
        
        for index, text in enumerate(text):
            info = Info(self, text=text, fg1=WHITE, bg1=GREEN, height=20)
            info.config({"ipady": 15 * index - 235})
            info.pack()
        
        panel = Panel(self, bg1=GREEN, size_hint=(None, 20))
        panel.pack(side=BOTTOM, expand_x=YES)
        
        btn = Button(panel, text="::", size_hint=(20, 15), fun=lambda: self.getRoot().setCurrent(self.getRoot().pager))
        btn.config({"ipadx": 2})
        btn.pack(side=RIGHT)
                
class Aeon(App):
    
    def onCreate(self, info):
        super(Aeon, self).onCreate(info, title="Aeon Media Player", size=(1000, 750))
        self.manager = Manager()
        self.form = None    
        self.mediaList = MediaList(self)
        self.audioControl = AudioControl(self)
        self.videoControl = VideoControl(self)
        self.videoList = VideoList(self)
        self.audioList = AudioList(self)
        self.artistList = ArtistList(self)
        self.albumList = AlbumList(self)
        self.about = About(self)
        self.pager = Pager(self)
        self.now_playing = self.mediaList
        self.setCurrent(self.pager)
        
    def isAudio(self, file):
        return os.path.isfile(file) and file.lower().endswith((".mp3", ".wav", ".amr", ".m4a", ".mid", ".ogg"))
    
    def isVideo(self, file):
        return os.path.isfile(file) and file.lower().endswith((".mp4", ".flv", ".mkv", ".avi", ".mpg"))
        
    def openFile(self, file):
        if self.isVideo(file):
            self.setCurrent(self.videoControl)
            self.videoControl.Play(file)
        elif self.isAudio(file):
            self.setCurrent(self.audioControl)
            self.audioControl.Play(file)
        
    def setCurrent(self, form):
        if self.form is not None:
            self.form.unpack()
        form.pack(expand_x=YES, expand_y=YES)
        form.refresh()
        self.form = form
        
if __name__ == "__main__":
    Aeon().run()

# colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (125, 0, 0, 125)
GREEN = (0, 125, 0, 125)
GREY = (100, 100, 100, 125)
SILVER = (192, 192, 192, 125)
LIGHT_BLUE = (0, 125, 125, 125)

# constants
CENTER = "center"
TOP = "top"
BOTTOM = "bottom"
LEFT = "left"
RIGHT = "right"
UP = "up"
DOWN = "down"
YES = "yes"
NO = "no"

# mouse clicks
LEFT_CLICK = 1
MIDDLE_CLICK = 2
RIGHT_CLICK = 3
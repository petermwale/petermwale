import file

print(help(file))
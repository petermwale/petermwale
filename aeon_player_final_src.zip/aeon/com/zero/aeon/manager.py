import sqlite3

class Manager:
    
    def create(self):
        try:
            with sqlite3.connect("./././data/cryptic/playlist.db") as db:
                cursor = db.cursor()
                cursor.execute("CREATE TABLE media (src text, kind text, artist text, album text, title text)")
            db.commit()
        except Exception as err:
            print("Error creating database './././data/cryptic/playlist.db':", err)  
        else:
            print("Created database './././data/cryptic/playlist.db' successfully!")  
            
    def add(self, src, kind, artist="artist", album="album", title="artist"):        
        try:
            with sqlite3.connect("./././data/cryptic/playlist.db") as db:
                cursor = db.cursor()
                cursor.execute("INSERT INTO media (src, kind, artist, album, title) VALUES \
                    ('{0}', '{1}', '{2}', '{3}', '{4}')".format(src, kind, artist, album, title))       
                db.commit()
            print("Wrote data to database './././data/cryptic/playlist.db' successfully!")
            return True
        except Exception as err:
            print("Error writing to database './././data/cryptic/playlist.db':", err)   
            return None 
        
    def delete(self, src):
        try:
            with sqlite3.connect("./././data/cryptic/playlist.db") as db:
                cursor = db.cursor() 
                cursor.execute("DELETE FROM media WHERE src = '{0}'".format(src))  
                db.commit()
            print("Deleted data from database './././data/cryptic/playlist.db' successfully!".format(src))   
        except Exception as err:
            print("Error deleting data from database './././data/cryptic/playlist.db':", err)  
            
    def get(self):
        try:
            with sqlite3.connect("./././data/cryptic/playlist.db") as db:
                cursor = db.cursor()
                cursor = db.execute("SELECT * FROM media")
            return {x[0]: (x[1], x[2], x[3], x[4]) for x in cursor}
        except Exception as err:
            print("Error accessing database './././data/cryptic/playlist.db':", err)
            return None
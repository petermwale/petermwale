import pygame, pyglet, sys, os
from pygame.locals import *
from .const import *
from com.zero.aeon.timer import Timer


os.environ["SDL_VIDEO_CENTERED"] = "1" # Put Window at the center
pygame.init() # Initialize Pygame system modules

class App:
    
    ROOT = TOP_LEVEL = True

    def onCreate(self, info, title="App", size=(640, 480), icon=None):
        #info = pygame.display.Info()
        self.fullscreen_size = info.current_w, info.current_h
        self.screen = pygame.display.set_mode(size, RESIZABLE)
        self.size = size
        self.setTitle(title)

        if icon is not None:
            self.setIcon(icon)
            
        self.x = self.y = 0            
        self.children = []
        
        self.grabbed_child = None
        self.is_fullscreen = False
        self.mouse_click_count = 0
        
        self.name = self.__class__.__name__.lower()         
        self.clock = pygame.time.Clock()
        self.timer = Timer()

    def setTitle(self, title):
        pygame.display.set_caption(title)

    def setIcon(self, icon):
        try:
            pygame.display.set_icon(pygame.image.load(icon).convert_alpha())
        except:
            pass
        
    def switchFullscreen(self):
        self.is_fullscreen = not self.is_fullscreen
        if self.is_fullscreen:
            self.last_size = self.size
            self.resizeWin(self.fullscreen_size, True)
        else:
            self.resizeWin(self.last_size)

    def resizeWin(self, size, fullscreen=False):
        self.screen = pygame.display.set_mode(size, FULLSCREEN  if fullscreen else RESIZABLE)
        self.size = size
        
    def addChild(self, child):
        child.child_pos = len(self.children)
        self.children.append(child)
        
    def removeChild(self, child):
        self.children.remove((child))
        
    def drawChildren(self):
        for child in self.children:
            child.draw()
            
    def keyDown(self, key, char):
        if self.grabbed_child is not None:
            self.grabbed_child.keyDown(key, char)
            return
        for child in self.children:
            child.keyDown(key, char)
            
    def keyUp(self, key):
        if self.grabbed_child is not None:
            self.grabbed_child.keyUp(key)
            return
        for child in self.children:
            child.keyUp(key)
            
    def dropFile(self, file):
        if self.grabbed_child is not None:
            self.grabbed_child.dropFile(file)
            return
        for child in self.children:
            child.dropFile(file)        
            
    def mouseDown(self, pos, btn, double_click):
        if self.grabbed_child is not None:
            self.grabbed_child.mouseDown(pos, btn, double_click)
            return
        for child in self.children:
            child.mouseDown(pos, btn, double_click)
            
    def mouseUp(self, pos, btn):
        if self.grabbed_child is not None:
            self.grabbed_child.mouseUp(pos, btn)
            return
        for child in self.children:
            child.mouseUp(pos, btn)
            
    def mouseMoved(self, pos):
        if self.grabbed_child is not None:
            self.grabbed_child.mouseMoved(pos)
            return
        for child in self.children:
            child.mouseMoved(pos)
            
    def mouseDragged(self, pos):
        if self.grabbed_child is not None:
            self.grabbed_child.mouseDragged(pos)
            return
        for child in self.children:
            child.mouseDragged(pos)

    def run(self, info=None):
        if info is None:
            info = pygame.display.Info()
        self.onCreate(info)
        while True:
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit()
                elif event.type == VIDEORESIZE:
                    self.resizeWin(event.size)
                elif event.type == MOUSEMOTION:
                    self.mouseMoved(event.pos)
                    if event.buttons[0]:
                        self.mouseDragged(event.pos)
                elif event.type == MOUSEBUTTONDOWN:
                    self.mouseDown(event.pos, event.button, True if self.mouse_click_count < 35 else False)
                    self.mouse_click_count = 0
                elif event.type == MOUSEBUTTONUP:
                    self.mouseUp(event.pos, event.button)
                elif event.type == KEYDOWN:
                    self.keyDown(event.key, event.unicode)
                elif event.type == KEYUP:
                    self.keyUp(event.key)
                elif event.type == DROPFILE:
                    self.dropFile(event.file)
                    
            self.clock.tick(120)
            pyglet.clock.tick(1)
            self.timer.tick()
            self.mouse_click_count += 1
            self.screen.fill(WHITE)
            self.drawChildren()
            pygame.display.update()
import pygame, sys, os
from pygame.locals import *
from com.zero.aeon.const import *
from aeon import Aeon

os.environ["SDL_VIDEO_CENTERED"] = "1" # Put Window at the center

def setup():
    global screen, clock, image, text1, text2, info
    info = pygame.display.Info()
    screen = pygame.display.set_mode((650, 480), NOFRAME)
    clock = pygame.time.Clock()
    image = pygame.image.load("data/image/icon.png")
    font1 = pygame.font.SysFont("Calibri", 25, bold=True)
    font2 = pygame.font.SysFont("Calibri", 18, bold=True)
    text1 = font1.render("Aeon Media Player", True, SILVER)
    text2 = font2.render("Courtesy of Sub-Zero Inc. © 2021 By Peter Mwale.", True, SILVER)
    
def run():
    while True:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                pygame.quit()
                sys.exit()
        
        clock.tick(120)  
        
        if pygame.time.get_ticks() % 750 == 0:
           break
                      
        screen.fill((50,65,50))
        w1, h1 = screen.get_size()
        w2, h2 = image.get_size()
        screen.blit(image, (w1 // 2 - w2 // 2, h1 // 2 - h2 // 2))
        #screen.blit(text1, (5, 5))
        screen.blit(text2, (5, h1 - text1.get_height() - 2))
        pygame.display.update()
        
    Aeon().run(info)
        
if __name__ == "__main__":
    setup()
    run()